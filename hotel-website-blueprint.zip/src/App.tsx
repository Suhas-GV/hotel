/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Cover } from './components/Cover';
import { Pillars } from './components/Pillars';
import { Pages } from './components/Pages';
import { BookingEngine } from './components/BookingEngine';
import { SEO } from './components/SEO';
import { TechStack } from './components/TechStack';
import { Timeline } from './components/Timeline';
import { KPIs } from './components/KPIs';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-hotel-cream text-hotel-charcoal font-sans selection:bg-hotel-gold/30">
      <Cover />
      <Pillars />
      <Pages />
      <BookingEngine />
      <SEO />
      <div className="max-w-6xl mx-auto px-8 md:px-12"><hr className="border-t border-hotel-cream-dark" /></div>
      <TechStack />
      <div className="max-w-6xl mx-auto px-8 md:px-12"><hr className="border-t border-hotel-cream-dark" /></div>
      <Timeline />
      <KPIs />
      <Footer />
    </div>
  );
}
