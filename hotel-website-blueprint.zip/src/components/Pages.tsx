import React from 'react';

const pagesData = [
  {
    idx: '01',
    title: 'Homepage — Desire in 5 Seconds',
    desc: 'The single most important page. Within 5 seconds, a visitor must feel the atmosphere and understand the unique value of your property. The hero must be full-viewport video or photography — never a slideshow. Place the booking widget above the fold, always visible. Lead with the guest experience, not your amenity list.',
    tags: [
      { text: 'Booking Widget Above Fold', type: 'gold' },
      { text: 'Hero Video / Photography', type: 'rust' },
      { text: 'Best Rate Guarantee Banner', type: 'default' },
      { text: 'TripAdvisor / Google Rating', type: 'teal' },
      { text: 'Property USP Strip', type: 'default' },
      { text: 'Seasonal Offer CTA', type: 'gold' },
    ],
    priority: 'Critical',
    pClass: 'bg-hotel-rust/10 text-hotel-rust'
  },
  {
    idx: '02',
    title: 'Rooms & Suites — The Decision Page',
    desc: 'This is where guests commit. Each room must have a dedicated sub-page with a full-screen photo gallery (minimum 8 images), a clear amenity list, size and view details, and a direct "Book This Room" CTA. Room descriptions must use sensory language, not spec sheets. Comparison tools and filters by view, size, or price significantly lift conversion.',
    tags: [
      { text: 'Full-Screen Gallery (8+ Images)', type: 'rust' },
      { text: 'Per-Room Book Button', type: 'gold' },
      { text: 'Amenity Checklist', type: 'default' },
      { text: 'Room Size & View Details', type: 'default' },
      { text: 'Room Comparison Tool', type: 'teal' },
      { text: 'Upsell: Next Room Category', type: 'gold' },
    ],
    priority: 'Critical',
    pClass: 'bg-hotel-rust/10 text-hotel-rust'
  },
  {
    idx: '03',
    title: 'Dining — Sell the Full Experience',
    desc: 'Dining is a major booking motivator, especially for leisure travellers. Feature your restaurant with the same visual and copywriting quality as the rooms. Include menus (PDF or embedded), reservation options, chef credentials, and signature dish photography. Breakfast inclusion details must be prominent — it\'s a key search filter for families and couples.',
    tags: [
      { text: 'Menu Photography', type: 'rust' },
      { text: 'Table Reservation CTA', type: 'gold' },
      { text: 'Chef Profile', type: 'default' },
      { text: 'Menus (PDF Download)', type: 'default' },
      { text: 'Opening Hours', type: 'teal' },
      { text: 'Breakfast Info Prominently Placed', type: 'default' },
    ],
    priority: 'Critical',
    pClass: 'bg-hotel-rust/10 text-hotel-rust'
  },
  {
    idx: '04',
    title: 'Offers & Packages — The Revenue Page',
    desc: 'The most commercially powerful page on the site. Packages that bundle rooms with dining, spa, or experiences convert 35–60% better than room-only rates. Each offer needs urgency (limited dates, countdown), a clear saving, and its own landing page for paid ads. Seasonal offers should rotate — a stale offers page destroys trust.',
    tags: [
      { text: 'Seasonal Packages', type: 'gold' },
      { text: 'Urgency / Scarcity Indicators', type: 'rust' },
      { text: 'Book Now CTA per Offer', type: 'gold' },
      { text: 'Newsletter Exclusive Deals', type: 'teal' },
      { text: 'Savings Callouts', type: 'default' },
      { text: 'Offer Expiry Dates', type: 'default' },
    ],
    priority: 'High',
    pClass: 'bg-hotel-gold/10 text-[#7a5e20]'
  },
  {
    idx: '05',
    title: 'Weddings & Events — High-Value Lead Generation',
    desc: 'Weddings and corporate events represent some of the highest-value bookings a hotel receives. This page must inspire with atmospheric photography and lead with capacity, style, and unique venue features. Gate the brochure behind an email capture, include a venue enquiry form (not a generic contact form), and list catering and accommodation packages clearly.',
    tags: [
      { text: 'Venue Photography', type: 'rust' },
      { text: 'Brochure Download (Email Gate)', type: 'gold' },
      { text: 'Enquiry Form', type: 'gold' },
      { text: 'Capacity & Layout Details', type: 'default' },
      { text: 'Previous Events Gallery', type: 'teal' },
      { text: 'Catering & Accommodation Packages', type: 'default' },
    ],
    priority: 'High',
    pClass: 'bg-hotel-gold/10 text-[#7a5e20]'
  },
  {
    idx: '06',
    title: 'Spa & Wellness — Premium Upsell Page',
    desc: 'Spa pages drive both room upgrades and standalone day-visit bookings. Photography must evoke calm — low light, warm tones, minimal clutter. Feature treatment menus with online booking, day pass options, and exclusive spa + accommodation packages. This page is frequently used in retargeting campaigns.',
    tags: [
      { text: 'Treatment Menu & Online Booking', type: 'gold' },
      { text: 'Atmospheric Photography', type: 'rust' },
      { text: 'Day Pass Options', type: 'default' },
      { text: 'Spa + Room Packages', type: 'teal' },
      { text: 'Gift Vouchers CTA', type: 'default' },
    ],
    priority: 'High',
    pClass: 'bg-hotel-gold/10 text-[#7a5e20]'
  },
  {
    idx: '07',
    title: 'Location & Local Area — Contextualise the Stay',
    desc: 'Guests want to know what\'s nearby before booking. Feature an interactive map, curated local recommendations (restaurants, attractions, transport), and distance to key landmarks. This page also carries strong local SEO value. Include a "Getting Here" section with all transport options — it removes a common pre-booking anxiety.',
    tags: [
      { text: 'Interactive Map Embed', type: 'teal' },
      { text: 'Local Recommendations', type: 'default' },
      { text: 'Local SEO Anchor Text', type: 'teal' },
      { text: 'Getting Here (All Transport)', type: 'default' },
      { text: 'Parking & Transfers Info', type: 'default' },
    ],
    priority: 'High',
    pClass: 'bg-hotel-gold/10 text-[#7a5e20]'
  },
  {
    idx: '08',
    title: 'Guest Reviews — Social Proof Hub',
    desc: 'A dedicated reviews page (not just widget snippets) significantly increases booking confidence. Aggregate reviews from TripAdvisor, Google, and Booking.com. Curate responses from management — they show attentiveness. Include a "What Our Guests Say" video if possible. Link this page prominently from the homepage and rooms pages.',
    tags: [
      { text: 'Aggregated Review Feed', type: 'teal' },
      { text: 'Management Responses Shown', type: 'default' },
      { text: 'Guest Video Testimonials', type: 'rust' },
      { text: 'Star Rating Prominently Displayed', type: 'gold' },
      { text: 'Review Schema (Rich Snippets)', type: 'default' },
    ],
    priority: 'High',
    pClass: 'bg-hotel-gold/10 text-[#7a5e20]'
  },
  {
    idx: '09',
    title: 'Contact & FAQs — Remove the Last Objection',
    desc: 'Pre-arrival anxiety is a real barrier to booking. An FAQ section covering check-in times, pet policy, parking, cancellation, and accessibility reduces support load and seals hesitant bookings. Offer multiple contact options: form, phone, WhatsApp, and live chat. Response time expectations (e.g. "We reply within 2 hours") dramatically increase form completions.',
    tags: [
      { text: 'WhatsApp / Live Chat', type: 'gold' },
      { text: 'FAQ Section', type: 'default' },
      { text: 'Cancellation Policy', type: 'default' },
      { text: 'Local Business Schema', type: 'teal' },
      { text: 'Accessibility Info', type: 'default' },
      { text: 'Response Time Expectation', type: 'gold' },
    ],
    priority: 'Standard',
    pClass: 'bg-hotel-teal/10 text-hotel-teal'
  }
];

export function Pages() {
  const getTagClass = (type: string) => {
    switch (type) {
      case 'gold': return 'bg-hotel-gold/10 text-[#7a5e20]';
      case 'teal': return 'bg-hotel-teal/10 text-hotel-teal';
      case 'rust': return 'bg-hotel-rust/10 text-hotel-rust';
      default: return 'bg-hotel-cream-dark text-hotel-charcoal';
    }
  };

  return (
    <section className="max-w-6xl mx-auto py-24 px-8 md:px-12">
      <div className="text-[10px] tracking-[4px] uppercase text-hotel-gold font-medium mb-3">Site Architecture</div>
      <h2 className="font-serif text-3xl md:text-5xl font-light text-hotel-charcoal leading-tight mb-4">
        The 9 Pages That<br /><em className="italic text-hotel-gold">Drive Direct Bookings</em>
      </h2>
      <p className="text-[15px] font-light text-hotel-stone max-w-2xl mb-14 leading-relaxed">
        Each page serves a precise role in the guest's decision journey, from first impression to confirmed reservation. Priority indicates where to concentrate design and copywriting effort at launch.
      </p>

      <div className="flex flex-col">
        {pagesData.map((page, i) => (
          <div key={i} className="grid grid-cols-[36px_1fr] md:grid-cols-[48px_1fr_110px] gap-6 md:gap-8 items-start py-9 border-b border-hotel-cream-dark last:border-0">
            <div className="font-serif text-4xl md:text-5xl font-light text-hotel-sand leading-none pt-1">{page.idx}</div>
            <div>
              <h3 className="font-serif text-2xl font-semibold text-hotel-charcoal mb-2">{page.title}</h3>
              <p className="text-[13px] text-hotel-stone font-light mb-5 leading-relaxed">{page.desc}</p>
              <div className="flex flex-wrap gap-2">
                {page.tags.map((tag, j) => (
                  <span key={j} className={`text-[11px] font-normal tracking-[0.5px] px-3 py-1 rounded-sm ${getTagClass(tag.type)}`}>
                    {tag.text}
                  </span>
                ))}
              </div>
            </div>
            <span className={`hidden md:block text-[10px] font-medium tracking-[2px] uppercase px-3 py-1.5 rounded-sm text-center whitespace-nowrap self-start ${page.pClass}`}>
              {page.priority}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}
