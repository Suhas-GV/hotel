import React from 'react';

export function TechStack() {
  return (
    <section className="max-w-6xl mx-auto py-24 px-8 md:px-12">
      <div className="text-[10px] tracking-[4px] uppercase text-hotel-gold font-medium mb-3">Technology</div>
      <h2 className="font-serif text-3xl md:text-5xl font-light text-hotel-charcoal leading-tight mb-4">
        The Complete<br /><em className="italic text-hotel-gold">Hotel Tech Stack</em>
      </h2>
      <p className="text-[15px] font-light text-hotel-stone max-w-2xl mb-14 leading-relaxed">
        Every tool below should integrate — data should flow between your CMS, booking engine, CRM, and analytics without manual work.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { icon: '🏗️', title: 'CMS Platform', desc: 'Powers content updates without a developer. Must support booking engine embeds natively.', examples: 'WordPress + Elementor · Craft CMS · Webflow' },
          { icon: '🛎️', title: 'Booking Engine', desc: 'The revenue core. Must stay on your domain, integrate with PMS, and support upsells.', examples: 'SiteMinder · Cloudbeds · Triptease' },
          { icon: '📊', title: 'Analytics & CRO', desc: 'Track booking funnel drop-offs and test improvements with A/B experiments.', examples: 'GA4 · Hotjar · Google Optimize' },
          { icon: '📨', title: 'Email & CRM', desc: 'Nurture enquiries, re-market past guests, and drive repeat bookings with automated flows.', examples: 'Mailchimp · HubSpot · Revinate' },
          { icon: '💬', title: 'Live Chat & Messaging', desc: 'Engage high-intent visitors in real time. WhatsApp integration is increasingly expected.', examples: 'Tidio · Intercom · WhatsApp Business' },
          { icon: '⭐', title: 'Review Management', desc: 'Aggregate TripAdvisor, Google, and Booking.com reviews and respond from one dashboard.', examples: 'TrustYou · Revinate · ReviewPro' },
          { icon: '🖼️', title: 'Media & CDN', desc: 'Serve compressed, responsive images at maximum speed globally. Essential for visual-heavy hotel sites.', examples: 'Cloudinary · Imgix · Cloudflare CDN' },
          { icon: '🎯', title: 'Paid Retargeting', desc: "Re-capture visitors who browsed rooms but didn't book. Hotel retargeting ROI is among the highest in travel.", examples: 'Google Ads · Meta Ads · Criteo' },
          { icon: '🔒', title: 'Hosting & Security', desc: 'Managed WordPress hosting with automated backups, SSL, and 99.9% uptime SLA.', examples: 'Kinsta · WP Engine · SiteGround' }
        ].map((item, i) => (
          <div key={i} className="bg-white p-6 rounded-sm shadow-[0_2px_8px_rgba(0,0,0,0.05)] border-l-[3px] border-hotel-charcoal hover:border-hotel-gold transition-colors duration-200">
            <div className="text-2xl mb-3">{item.icon}</div>
            <h4 className="text-[13px] font-semibold text-hotel-charcoal tracking-[0.5px] mb-1">{item.title}</h4>
            <p className="text-xs text-hotel-stone font-light mb-2.5 leading-relaxed">{item.desc}</p>
            <div className="text-[11px] font-medium text-hotel-gold tracking-[0.5px]">{item.examples}</div>
          </div>
        ))}
      </div>
    </section>
  );
}
