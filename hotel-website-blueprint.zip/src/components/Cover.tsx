import React from 'react';

export function Cover() {
  return (
    <div className="bg-hotel-black min-h-screen grid grid-cols-1 md:grid-cols-2 overflow-hidden">
      <div className="flex flex-col justify-center py-20 px-8 md:px-16 relative z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-hotel-gold/5 to-transparent pointer-events-none"></div>
        <div className="text-[10px] font-medium tracking-[5px] uppercase text-hotel-gold mb-8 flex items-center gap-4">
          <span className="w-8 h-[1px] bg-hotel-gold block"></span>
          Strategic Website Blueprint
        </div>
        <h1 className="font-serif text-4xl md:text-5xl lg:text-7xl font-light text-hotel-cream leading-tight mb-7">
          The <em className="italic text-hotel-gold-light">High-Converting</em><br />Hotel Website
        </h1>
        <p className="text-sm font-light text-hotel-stone max-w-md mb-12 leading-relaxed">
          A complete, phase-by-phase blueprint to maximise direct bookings, reduce OTA dependency, and turn every visitor into a guest — on your terms.
        </p>
        <div className="flex flex-wrap gap-8 pt-8 border-t border-hotel-gold/20">
          <div className="flex flex-col">
            <span className="font-serif text-4xl font-semibold text-hotel-gold leading-none">9</span>
            <span className="text-[10px] tracking-[2px] uppercase text-hotel-stone font-light mt-1">Core Pages</span>
          </div>
          <div className="flex flex-col">
            <span className="font-serif text-4xl font-semibold text-hotel-gold leading-none">5</span>
            <span className="text-[10px] tracking-[2px] uppercase text-hotel-stone font-light mt-1">Phases</span>
          </div>
          <div className="flex flex-col">
            <span className="font-serif text-4xl font-semibold text-hotel-gold leading-none">14</span>
            <span className="text-[10px] tracking-[2px] uppercase text-hotel-stone font-light mt-1">Wks to Launch</span>
          </div>
          <div className="flex flex-col">
            <span className="font-serif text-4xl font-semibold text-hotel-gold leading-none">30%</span>
            <span className="text-[10px] tracking-[2px] uppercase text-hotel-stone font-light mt-1">OTA Fee Saved</span>
          </div>
        </div>
      </div>
      <div className="hidden md:block relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-hotel-black to-transparent z-10 w-2/5"></div>
        <div className="absolute inset-0 bg-gradient-to-br from-[#1a1208] to-hotel-black z-0"></div>
        <div className="absolute inset-0 z-0 opacity-20" style={{
          backgroundImage: `repeating-linear-gradient(45deg, var(--color-hotel-gold) 0px, var(--color-hotel-gold) 1px, transparent 1px, transparent 40px), repeating-linear-gradient(-45deg, var(--color-hotel-gold) 0px, var(--color-hotel-gold) 1px, transparent 1px, transparent 40px)`
        }}></div>
        <div className="absolute inset-0 z-10 flex flex-col justify-end p-16">
          <div className="mb-8">
            <span className="font-serif text-[80px] font-light text-hotel-gold/15 leading-none block">72%</span>
            <span className="text-[11px] tracking-[3px] uppercase text-hotel-gold/40 font-light">of travellers visit a hotel's own site before booking via an OTA</span>
          </div>
          <div>
            <span className="font-serif text-[80px] font-light text-hotel-gold/15 leading-none block">15–30%</span>
            <span className="text-[11px] tracking-[3px] uppercase text-hotel-gold/40 font-light">commission lost on every OTA booking your website could have captured</span>
          </div>
        </div>
      </div>
    </div>
  );
}
