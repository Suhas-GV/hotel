import React from 'react';

export function BookingEngine() {
  return (
    <div className="bg-hotel-charcoal py-20">
      <div className="max-w-6xl mx-auto px-8 md:px-12">
        <div className="text-[10px] tracking-[4px] uppercase text-hotel-gold font-medium mb-3">The Most Important Technical Decision</div>
        <h2 className="font-serif text-3xl md:text-5xl font-light text-hotel-cream leading-tight mb-4">
          Choosing Your <em className="italic text-hotel-gold-light">Booking Engine</em>
        </h2>
        <p className="text-[14px] font-light text-hotel-stone max-w-2xl leading-relaxed">
          Your booking engine is the difference between a brochure and a revenue machine. It must be fast, mobile-first, and require zero redirects away from your domain.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-16 mt-12">
          <div>
            <h3 className="font-serif text-2xl font-semibold text-hotel-gold-light mb-5 pb-4 border-b border-hotel-gold/20">What Your Booking Engine Must Do</h3>
            <ul className="flex flex-col gap-3.5">
              {[
                'Load in under 2 seconds — booking abandonment spikes sharply after 3 seconds',
                'Stay on your domain (no redirects to third-party sites — this destroys trust)',
                'Display rate parity with OTAs and prominently show the "Book Direct" saving',
                'Offer one-click upsells: room upgrades, breakfast, late checkout, parking',
                'Support promo and discount codes for email campaigns and loyalty guests',
                'Capture email at checkout for post-stay re-marketing sequences',
                'Provide a seamless, native mobile experience (50%+ of hotel bookings are mobile)',
                'Integrate with your PMS (Property Management System) for live availability'
              ].map((item, i) => (
                <li key={i} className="flex gap-3.5 text-[14px] text-hotel-cream/60 font-light leading-relaxed">
                  <span className="text-hotel-gold text-base shrink-0 mt-[1px]">◆</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="font-serif text-2xl font-semibold text-hotel-gold-light mb-5 pb-4 border-b border-hotel-gold/20">Recommended Booking Engine Platforms</h3>
            <ul className="flex flex-col gap-3.5">
              {[
                <><strong className="text-hotel-cream font-medium">Triptease</strong> — Best for direct booking conversion tools and OTA parity monitoring</>,
                <><strong className="text-hotel-cream font-medium">SiteMinder</strong> — Industry-leading channel manager with native booking engine and wide PMS integrations</>,
                <><strong className="text-hotel-cream font-medium">Cloudbeds</strong> — All-in-one PMS + booking engine, ideal for independent hotels</>,
                <><strong className="text-hotel-cream font-medium">Little Hotelier</strong> — Best for boutique and small properties, simple but conversion-optimised</>,
                <><strong className="text-hotel-cream font-medium">Bookassist</strong> — Strong European hotel focus with integrated metasearch bidding</>,
                <>Whichever engine you choose: test the checkout flow on mobile before launch — most hotels never do</>
              ].map((item, i) => (
                <li key={i} className="flex gap-3.5 text-[14px] text-hotel-cream/60 font-light leading-relaxed">
                  <span className="text-hotel-gold text-base shrink-0 mt-[1px]">◆</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
