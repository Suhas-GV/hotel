import React from 'react';

export function Timeline() {
  return (
    <section className="max-w-6xl mx-auto py-24 px-8 md:px-12">
      <div className="text-[10px] tracking-[4px] uppercase text-hotel-gold font-medium mb-3">Project Plan</div>
      <h2 className="font-serif text-3xl md:text-5xl font-light text-hotel-charcoal leading-tight mb-4">
        14-Week<br /><em className="italic text-hotel-gold">Launch Plan</em>
      </h2>
      <p className="text-[15px] font-light text-hotel-stone max-w-2xl mb-14 leading-relaxed">
        Hotels require more pre-launch photography and content production than most industries. Build this time into the plan — rushing photography is the most common reason hotel websites underperform.
      </p>

      <div className="flex flex-col">
        {[
          {
            week: 'Weeks 1–2',
            title: 'Discovery & Strategy',
            num: '01',
            desc: 'Audit current site performance, identify the highest-value guest personas, agree on brand positioning (boutique? luxury? family? business?), lock the sitemap, and define the direct booking strategy before a single pixel is designed.',
            tasks: ['Guest persona workshops', 'OTA dependency audit', 'Competitor site analysis', 'Brand positioning document', 'Sitemap & feature sign-off', 'Booking engine selection']
          },
          {
            week: 'Weeks 3–5',
            title: 'Photography & Content Production',
            num: '02',
            desc: 'Commission a professional hospitality photographer — not a generalist. Brief them on hero images, room galleries (each room needs 8–12 images), dining, spa, and lifestyle shots with guests. Simultaneously brief a copywriter on tone of voice. Content and imagery are your biggest conversion levers: do not rush them.',
            tasks: ['Photography brief & shoot', 'Video / drone footage', 'Copywriting all 9 pages', 'Tone of voice document', 'Menu photography brief', 'Image editing & retouching']
          },
          {
            week: 'Weeks 4–9',
            title: 'Design & Build',
            num: '03',
            desc: 'Run design and development in parallel with content production. Begin with wireframes and high-fidelity mockups for Homepage, Rooms, and Offers pages — get stakeholder sign-off before building. Integrate booking engine, CRM, analytics, and review feeds. Design begins in Week 4 while photography completes.',
            tasks: ['Wireframes (key pages)', 'High-fidelity mockups', 'Stakeholder design sign-off', 'CMS build & templating', 'Booking engine integration', 'SEO structure & schema', 'CRM & analytics setup']
          },
          {
            week: 'Weeks 10–12',
            title: 'Testing & Optimisation',
            num: '04',
            desc: 'Complete QA across all devices and browsers. Test the entire booking flow end-to-end as a guest would — including mobile, upsell steps, and email confirmation. Run a real-guest feedback session with 5 people who match your target persona. Fix all friction points before launch.',
            tasks: ['Full booking flow test (mobile + desktop)', 'Cross-browser & device QA', 'PageSpeed & Core Web Vitals', '5-person user testing session', 'WCAG accessibility check', 'All forms & integrations tested']
          },
          {
            week: 'Weeks 13–14',
            title: 'Launch & Growth',
            num: '05',
            desc: 'Go live on a Tuesday or Wednesday (highest travel research traffic days). Announce across email, social, and to your OTA guest database where possible. Set up Google Search Console, submit sitemap, and activate retargeting pixel. Monitor booking funnel drop-offs daily in the first two weeks.',
            tasks: ['DNS migration & launch', 'Search Console & sitemap', 'Email announcement to past guests', 'Google & Meta Ads activation', 'Social media campaign', 'Week 1 funnel review & fixes']
          }
        ].map((phase, i) => (
          <div key={i} className="grid grid-cols-1 md:grid-cols-[200px_1fr] gap-4 md:gap-12 py-11 border-b border-hotel-cream-dark last:border-0 relative">
            <div className="pt-1">
              <div className="text-[10px] font-medium tracking-[3px] uppercase text-hotel-gold mb-1.5">{phase.week}</div>
              <h3 className="font-serif text-[26px] font-semibold text-hotel-charcoal leading-tight mb-2.5">{phase.title}</h3>
              <div className="font-serif text-7xl font-light text-hotel-cream-dark leading-none">{phase.num}</div>
            </div>
            <div>
              <p className="text-[14px] text-hotel-stone font-light leading-relaxed mb-5">{phase.desc}</p>
              <div className="flex flex-wrap gap-2">
                {phase.tasks.map((task, j) => (
                  <span key={j} className="text-xs bg-hotel-cream-dark text-hotel-charcoal px-3.5 py-1.5 rounded-sm font-normal">
                    {task}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
