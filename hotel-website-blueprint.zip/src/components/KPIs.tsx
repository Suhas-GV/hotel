import React from 'react';

export function KPIs() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-[2px] bg-hotel-sand">
      {[
        { val: '<2s', name: 'Booking Engine Load', desc: 'Every second of delay in the booking flow costs ~17% of completions. Target under 2 seconds on mobile 4G.' },
        { val: '4%+', name: 'Direct Booking Rate', desc: 'Visitors to confirmed bookings. Industry average is 2–3%. Hitting 4%+ means your funnel is genuinely working.' },
        { val: '30%+', name: 'Direct Revenue Share', desc: 'The % of total bookings that are direct (not OTA). Track monthly; every 1% shift saves significant commission.' },
        { val: '<60%', name: 'Booking Page Bounce', desc: 'If 60%+ of visitors leave the booking page without acting, the engine has a UX or pricing problem.' },
        { val: '2:00+', name: 'Avg. Time on Rooms Page', desc: 'Engaged guests spend 2+ minutes browsing rooms. Under 60 seconds signals poor imagery or confusing layout.' },
        { val: 'Top 3', name: 'Local Search Ranking', desc: 'Rank in the top 3 Google results for your key city/area + hotel search terms within 6 months of launch.' }
      ].map((kpi, i) => (
        <div key={i} className={`p-9 px-8 text-center ${i % 2 === 0 ? 'bg-hotel-charcoal' : 'bg-hotel-warm'}`}>
          <div className="font-serif text-5xl font-light text-hotel-gold leading-none mb-2">{kpi.val}</div>
          <div className="text-[11px] font-medium tracking-[2px] uppercase text-hotel-cream/55 mb-2.5">{kpi.name}</div>
          <div className="text-[13px] text-hotel-cream/35 font-light leading-relaxed">{kpi.desc}</div>
        </div>
      ))}
    </div>
  );
}
