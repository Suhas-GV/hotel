import React from 'react';

export function SEO() {
  return (
    <section className="max-w-6xl mx-auto py-24 px-8 md:px-12">
      <div className="text-[10px] tracking-[4px] uppercase text-hotel-gold font-medium mb-3">Search & Visibility</div>
      <h2 className="font-serif text-3xl md:text-5xl font-light text-hotel-charcoal leading-tight mb-4">
        SEO Strategy for<br /><em className="italic text-hotel-gold">Hotels That Want to Be Found</em>
      </h2>
      <p className="text-[15px] font-light text-hotel-stone max-w-2xl mb-14 leading-relaxed">
        OTAs dominate generic search. Your strategy must target high-intent, specific searches where you can win — and win profitably.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {[
          {
            title: 'Local SEO',
            desc: 'Owns the "near me" and city searches',
            items: [
              'Fully optimised Google Business Profile with photos updated monthly',
              'Target: "hotels in [city]", "boutique hotel [area]", "[hotel name] book direct"',
              'Local Business + Hotel schema markup on every relevant page',
              'Consistent NAP (Name, Address, Phone) across all directories',
              'Build local backlinks: tourism boards, wedding directories, local press',
              'Embed Google Map on Contact and Location pages'
            ]
          },
          {
            title: 'Content SEO',
            desc: 'Attracts guests in research phase',
            items: [
              'Publish 2 blog posts per month: local guides, seasonal itineraries, "things to do in [city]"',
              'Create dedicated landing pages for key occasions: "Romantic Weekend [City]", "Family Breaks [Region]"',
              'Optimise all image alt tags with descriptive, keyword-rich text',
              'Add FAQ schema to Contact and FAQs pages for rich snippet eligibility',
              'Internal link rooms, dining, and spa pages from every blog post'
            ]
          },
          {
            title: 'Technical SEO',
            desc: 'Ensures Google can find and rank you',
            items: [
              'Core Web Vitals passing: LCP under 2.5s, CLS under 0.1',
              'Submit XML sitemap to Google Search Console on launch day',
              'Canonical tags on all room variant pages to prevent duplicate content',
              '301 redirects from old site URLs if relaunching an existing property',
              'HTTPS on all pages — non-negotiable for both ranking and trust',
              'Mobile-first indexing compliance tested before launch'
            ]
          }
        ].map((card, i) => (
          <div key={i} className="bg-white rounded-sm overflow-hidden shadow-[0_2px_16px_rgba(0,0,0,0.06)]">
            <div className="bg-hotel-charcoal p-6">
              <h3 className="font-serif text-xl font-semibold text-hotel-gold-light mb-1">{card.title}</h3>
              <p className="text-xs text-hotel-stone font-light">{card.desc}</p>
            </div>
            <div className="p-6">
              <ul className="flex flex-col gap-2.5">
                {card.items.map((item, j) => (
                  <li key={j} className="text-[13px] text-hotel-stone font-light pl-4 relative leading-relaxed">
                    <span className="absolute left-0 text-hotel-gold">—</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
