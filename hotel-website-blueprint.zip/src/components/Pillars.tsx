import React from 'react';

export function Pillars() {
  return (
    <div className="bg-hotel-warm py-20">
      <div className="max-w-6xl mx-auto px-8 md:px-12">
        <div className="text-[10px] tracking-[4px] uppercase text-hotel-gold font-medium mb-3">Strategic Foundation</div>
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12 gap-8">
          <h2 className="font-serif text-3xl md:text-5xl font-light text-hotel-cream leading-tight">
            The 4 Pillars of Hotel<br /><em className="italic text-hotel-gold-light">Website Conversion</em>
          </h2>
          <p className="text-sm text-hotel-stone font-light max-w-xs leading-relaxed">
            Every design, content, and technology decision must serve at least one of these four principles — or it doesn't belong on the site.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-[2px]">
          {[
            {
              num: '01',
              title: 'Desire Before Logic',
              desc: 'Guests book with emotion, then justify with reason. Lead every page with aspirational imagery and sensory language. Let visitors feel the stay before they check the rate.'
            },
            {
              num: '02',
              title: 'Direct Booking Supremacy',
              desc: 'Every element of the site should funnel towards your own booking engine. Best rate guarantees, exclusive perks, and seamless checkout compete with Booking.com on your home turf.'
            },
            {
              num: '03',
              title: 'Frictionless Experience',
              desc: 'Slow pages, buried rates, and clunky mobile checkout kill reservations. Speed, clarity, and one-tap booking on mobile are non-negotiable in a post-OTA world.'
            },
            {
              num: '04',
              title: 'Trust at Every Touchpoint',
              desc: 'Reviews, accreditations, real photography, and transparent pricing eliminate the doubt that sends guests back to Booking.com. Trust is the last conversion lever most hotels ignore.'
            }
          ].map((pillar, idx) => (
            <div key={idx} className="bg-white/5 p-8 border-t border-hotel-gold/20 hover:bg-hotel-gold/5 transition-colors duration-300">
              <div className="font-serif text-5xl font-light text-hotel-gold/20 leading-none mb-4">{pillar.num}</div>
              <h3 className="font-serif text-xl font-semibold text-hotel-gold-light mb-3">{pillar.title}</h3>
              <p className="text-[13px] text-hotel-cream/50 font-light leading-relaxed">{pillar.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
