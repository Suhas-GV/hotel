import React from 'react';

export function Footer() {
  return (
    <footer className="bg-hotel-black text-hotel-cream/30 p-12 text-center text-xs font-light tracking-[1px]">
      <strong className="text-hotel-gold font-medium">Hotel Website Blueprint</strong> · Built for direct bookings, reduced OTA dependency, and long-term revenue growth.<br />
      Audit and update this plan every quarter — the hospitality landscape changes fast.
    </footer>
  );
}
